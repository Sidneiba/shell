#ifndef KERNEL_H
#define KERNEL_H

void kernel_main(void);

#endif
